from django.db import models

# Create your models here.
from django.db import models

# Create your models here.



class Persona(models.Model):
    name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    birth_date = models.DateField('Birth Date')
    description = models.CharField(max_length=200)
    resume = models.CharField(max_length=500)
    mail = models.EmailField(max_length=254)
    phone = models.CharField(max_length=12)
    photo = models.ImageField(upload_to ='uploads/')
    adress = models.CharField(max_length=50)
    LinkdIn = models.URLField(max_length=200, default="")
    Twitter = models.URLField(max_length=200, default="")
    Instagram = models.URLField(max_length=200, default="")
    def __str__(self):
        return self.last_name + ' ' + self.name

class Education(models.Model):
    persona = models.ForeignKey(Persona, on_delete=models.CASCADE)
    carreer_name = models.CharField(max_length=100)
    institution_name = models.CharField(max_length=100)
    start_date = models.DateField('Start Date')
    finish_date = models.DateField('Finish Date',null=True, blank=True)
    description = models.CharField(max_length=500)
    def __str__(self):
        return self.carreer_name

class Course(models.Model):
    persona = models.ForeignKey(Persona, on_delete=models.CASCADE)
    course_name = models.CharField(max_length=100)
    institution_name = models.CharField(max_length=150)
    start_date = models.DateField('Start Date')
    finish_date = models.DateField('Finish Date',null=True, blank=True)
    description = models.CharField(max_length=500)
    def __str__(self):
        return self.course_name

class Jobs(models.Model):
    persona = models.ForeignKey(Persona, on_delete=models.CASCADE)
    job_name = models.CharField(max_length=100)
    company_name = models.CharField(max_length=100)
    start_date = models.DateField('Start Date')
    finish_date = models.DateField('Finish Date',null=True, blank=True)
    job_description = models.CharField(max_length=1000)
    def __str__(self):
        return self.job_name

class Hobbie(models.Model):
    persona = models.ForeignKey(Persona, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=1000)
    def __str__(self):
        return self.name
    
