from django.contrib import admin

# Register your models here.
from django.contrib import admin

from .models import Persona, Jobs, Hobbie, Course, Education

admin.site.register(Persona)
admin.site.register(Jobs)
admin.site.register(Hobbie)
admin.site.register(Course)
admin.site.register(Education)
