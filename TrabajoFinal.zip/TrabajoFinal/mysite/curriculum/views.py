
from django.shortcuts import get_object_or_404, render
from django.template import loader
# Create your views here.
from django.http import HttpResponse
from .models import Persona, Jobs, Hobbie, Course, Education

def index(request, persona_id=1):
    persona = get_object_or_404(Persona, pk=persona_id)
    return render(request, 'curriculum/home.html', {'persona': persona})

def detail(request, persona_id=1):
    persona = get_object_or_404(Persona, pk=persona_id)
    return render(request, 'curriculum/hobbies.html', {'persona': persona})

def personal(request, persona_id=1):
    persona = get_object_or_404(Persona, pk=persona_id)
    return render(request, 'curriculum/personal_info.html', {'persona': persona})

def contact(request, persona_id=1):
    persona = get_object_or_404(Persona, pk=persona_id)
    return render(request, 'curriculum/contact_info.html', {'persona': persona})

def education(request, persona_id=1):
    persona = get_object_or_404(Persona, pk=persona_id)
    return render(request, 'curriculum/education.html', {'persona': persona})

def jobs(request, persona_id=1):
    persona = get_object_or_404(Persona, pk=persona_id)
    return render(request, 'curriculum/jobs.html', {'persona': persona})

def courses(request, persona_id=1):
    persona = get_object_or_404(Persona, pk=persona_id)
    return render(request, 'curriculum/courses.html', {'persona': persona})
