from django.urls import path

from . import views

urlpatterns = [
    # ex: /polls/
    path('', views.index, name='home'),
    # ex: /polls/5/
    path('hobbies.html', views.detail, name='hobbies'),

    path('personal_info.html', views.personal, name='personal_info'),

    path('contact_info.html', views.contact, name='contact_info'),

    path('courses.html', views.courses, name='courses_info'),

    path('jobs.html', views.jobs, name='jobs_info'),

    path('education.html', views.education, name='education_info'),

]