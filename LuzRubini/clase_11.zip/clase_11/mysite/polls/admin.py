from django.contrib import admin
from .models import estudiante
admin.site.register(estudiante)
# Register your models here.
