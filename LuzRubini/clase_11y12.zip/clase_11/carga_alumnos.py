Crear model estudiantes con los siguientes campos:
*Nombre
*Apellido
*DNI
*Legajo
*Fecha de Nacimiento
*Sexo
*Direccion
*Telefono

2. Generar migraciones
*con makemigrations

3.Ejecutar migraciones
*Con migrate