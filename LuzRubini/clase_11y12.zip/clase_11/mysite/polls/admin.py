from django.contrib import admin
from .models import estudiante,Question, Choice
admin.site.register(estudiante)
admin.site.register(Question)
admin.site.register(Choice)
# Register your models here.
